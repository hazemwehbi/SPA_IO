<?php

namespace Tests;

use PHPUnit\Framework\TestCase as BaseTestCase;

abstract class SimpleTestCase extends BaseTestCase
{
    //
}
